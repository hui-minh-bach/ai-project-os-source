// Local preview only. Not a production installer.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.join(path.dirname(fileURLToPath(import.meta.url)),'app');
const port=Number(process.argv[2]||8080);if(!Number.isInteger(port)||port<1024||port>65535)throw new Error('Port 1024..65535 required');
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.gif':'image/gif','.webp':'image/webp','.ico':'image/x-icon','.woff':'font/woff','.woff2':'font/woff2','.ttf':'font/ttf','.txt':'text/plain; charset=utf-8'};
http.createServer((req,res)=>{try{if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);res.end();return;}let rel=decodeURIComponent(new URL(req.url,'http://127.0.0.1').pathname).replace(/^\/+/, '');if(!rel||rel.endsWith('/'))rel+='index.html';const file=path.resolve(root,rel);if(!file.startsWith(root+path.sep))throw new Error('Path');let cur=root;for(const part of path.relative(root,file).split(path.sep)){cur=path.join(cur,part);if(fs.lstatSync(cur).isSymbolicLink())throw new Error('Symlink');}if(!mime[path.extname(file).toLowerCase()]||!fs.statSync(file).isFile())throw new Error('File');res.writeHead(200,{'content-type':mime[path.extname(file).toLowerCase()],'x-content-type-options':'nosniff','cache-control':'no-store'});if(req.method==='HEAD')res.end();else fs.createReadStream(file).pipe(res);}catch{res.writeHead(404);res.end('Not found');}}).listen(port,'127.0.0.1',()=>console.log('Local preview: http://127.0.0.1:'+port));
