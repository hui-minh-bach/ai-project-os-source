# Cài đặt/chạy thủ công · v0.1.0

Đích: Máy chủ nội bộ · On-premises Server

1. Giải nén gói vào thư mục mới; kiểm tra VERSION.json và SHA256SUMS.json.
2. Xem config.example.json: website tĩnh không cần credential server. Không đặt secret vào frontend.
3. Xem trước cục bộ: máy có Node.js 22 trở lên, mở terminal tại thư mục gói và chạy `node preview.mjs 8080`; mở http://127.0.0.1:8080. Không có npm install/build trong gói.
4. Đọc TEST-RESULTS.json và Release Notes, rồi kiểm tra acceptance ở máy đích.

Đưa thư mục app/ vào web server có sẵn do quản trị viên quản lý, bằng thao tác thủ công. Quản trị viên tự cấu hình HTTPS, quyền truy cập, backup và mạng theo Architecture đã duyệt. preview.mjs chỉ bind loopback để xem trước; không dùng làm server production. Không có SSH, upload, cài đặt server hay tạo tài khoản cloud tự động.

Đóng gói thành công không có nghĩa Deployed. PO chỉ xác nhận triển khai sau khi thực sự kiểm tra máy đích.
