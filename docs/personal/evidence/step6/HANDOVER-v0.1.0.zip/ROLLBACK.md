# Rollback thủ công

Giữ gói của phiên bản trước và sao lưu cấu hình/dữ liệu trước khi thay đổi. Nếu bản mới lỗi, phục hồi thư mục app/ của gói trước vào vị trí cũ bằng thao tác thủ công, đối chiếu VERSION.json và kiểm tra lại. Không tự xóa dữ liệu trình duyệt/localStorage. Nếu chưa có bản trước thì chưa có gói rollback; giữ nguyên trạng và xử lý với PO. Không có lệnh tự thay hệ thống hoặc database.
